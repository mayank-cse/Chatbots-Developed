﻿using System;
using System.Linq;

namespace Microsoft.Bot.Connector
{
    /// <summary>
    /// The From address is typing
    /// </summary>
    public interface ITypingActivity : IActivity
    {
    }
}
