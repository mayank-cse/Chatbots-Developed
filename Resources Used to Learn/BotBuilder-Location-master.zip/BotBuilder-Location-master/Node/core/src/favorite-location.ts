import { RawLocation } from './rawLocation';

export class FavoriteLocation {
    name: string;
    location: RawLocation;
}