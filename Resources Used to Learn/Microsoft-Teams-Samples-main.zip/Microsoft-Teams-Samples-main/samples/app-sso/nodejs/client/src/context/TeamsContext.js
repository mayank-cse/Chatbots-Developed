import React from 'react';

const TeamsContext = React.createContext();

export default TeamsContext;