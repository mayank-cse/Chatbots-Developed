// eslint-disable-next-line import/no-anonymous-default-export
export default {
    timeout: 10000,
    refreshInterval: 3000,
}