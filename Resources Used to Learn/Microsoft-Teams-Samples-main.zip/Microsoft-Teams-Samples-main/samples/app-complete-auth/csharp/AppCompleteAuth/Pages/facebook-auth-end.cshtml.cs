using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppCompleteAuth.Pages
{
    public class facebookAuthEnd : PageModel
    {
        public void OnGet()
        { 
        }
    }
}
