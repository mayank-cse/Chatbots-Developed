using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppCompleteAuth.Pages
{
    public class authEnd : PageModel
    {
        public void OnGet()
        { 
        }
    }
}
