﻿
namespace Microsoft.Teams.TemplateBotCSharp.src.dialogs
{
    public class RootDialogState
    {
        public string LastDialogKey { get; set; }

        public string SetUpMsgKey { get; set; }
    }
}