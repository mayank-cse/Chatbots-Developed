using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppCheckinLocation.Pages
{
    public class ViewLocationModel
        : PageModel
    {
        public void OnGet()
        {
        }
    }
}
