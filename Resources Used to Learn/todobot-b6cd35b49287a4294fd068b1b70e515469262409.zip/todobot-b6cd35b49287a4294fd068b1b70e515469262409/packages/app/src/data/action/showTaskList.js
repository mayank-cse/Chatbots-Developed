const SHOW_TASK_LIST = 'SHOW_TASK_LIST';

export default function showTaskList() {
  return {
    type: SHOW_TASK_LIST
  };
}

export { SHOW_TASK_LIST }
