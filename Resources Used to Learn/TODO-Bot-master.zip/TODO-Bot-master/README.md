# TODO-Bot

Todo bot writting in C# as part of the weekly challenge of http://thedevchannel.com/

#Features
* Add item to the todo-list
* Remove item from the todo-list
* Edit items on the todo-list
* Add deadlines to items
* Mark items as done

#Building-Linux

Make sure you have the latest version of mono(4.2.2) installed. We have not done any testing with
previous versions. Then you should simply be able to run build-linux.sh, which compiles the bot.
Finally you can do run-linux.sh to run the bot.

#Building-Windows

Add csc.exe (> .Net 4.0) to your PATH environment variable. Then run build-windows.bat followed by
run-windows.bat.
(We haven't actually been able to test this, but theoretically it should work. If it does not, contact
one of us).

#Authors
ferdie
vaggelisd