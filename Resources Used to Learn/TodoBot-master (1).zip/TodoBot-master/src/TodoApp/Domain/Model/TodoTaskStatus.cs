﻿namespace TodoApp.Domain.Model
{
    public enum TodoTaskStatus
    {
        Pending,
        InProgress,
        Finished
    }
}