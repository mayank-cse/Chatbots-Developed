# TODO Bot with Bot Builder SDK v4

This the repo for the blog post: [Explorando el Bot Builder SDK v4 con TDD en ASP.NET Core 2.1](https://blog.turingchallenge.com/posts/explorando-bot-builder-v4-tdd-aspnet-core-2.1/), where we explore the SDK using a high level TDD approach.
