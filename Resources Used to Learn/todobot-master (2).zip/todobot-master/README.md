# todobot

> This is Progressive Web App (PWA). Feel free to add your home screen so you can show it to others.

Please browse to https://todobot.azurewebsites.net/ for demo.

## Features

- On mobile screen without too much real estate (<= 480 pixels), this will show chat experience only
- On desktop with many real estate, this will show both the app and chat experience
   - Both app and chat experience are connected, modifying the to-do list on one side will be reflected on the other side immediately
